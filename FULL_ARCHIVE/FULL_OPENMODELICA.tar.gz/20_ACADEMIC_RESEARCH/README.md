# 20 Academic Research

**Project:** OPENMODELICA
**Upstream:** https://github.com/OpenModelica/OpenModelica

Content specific to OPENMODELICA in category CHEMICAL_PRODUCTION.
