# 18 Command Line Interface

**Project:** OPENMODELICA
**Upstream:** https://github.com/OpenModelica/OpenModelica

Content specific to OPENMODELICA in category CHEMICAL_PRODUCTION.
